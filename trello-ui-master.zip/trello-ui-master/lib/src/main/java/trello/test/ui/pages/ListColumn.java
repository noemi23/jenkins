package trello.test.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ListColumn extends AbstractPage {
    @FindBy(css = ".list-header")
    private WebElement listTitleLabel;

    public ListColumn() {
        super();
    }

    public String getListTitle(){
        return this.action.getText(this.listTitleLabel);
    }
}
