package trello.test.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeftMenuBar extends AbstractPage{
    @FindBy(css = "[href*='boards']")
    private WebElement boardsMenuItem;

    public LeftMenuBar() {
        super();
    }

    public BoardsPage openBoardsPage(){
        this.action.click(boardsMenuItem);
        return new BoardsPage();
    }
}
