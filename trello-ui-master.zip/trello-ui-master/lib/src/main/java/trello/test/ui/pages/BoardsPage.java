package trello.test.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BoardsPage extends AbstractPage {
    @FindBy(xpath =  "//div[@class='content-all-boards']/div[2]/descendant::li[@data-test-id='create-board-tile']")
    private WebElement createNewBoardButton;

    public BoardsPage() {
        super();
    }

    public BoardCreationForm openCreateBoardForm(){
        this.action.click(createNewBoardButton);
        return new BoardCreationForm();
    }
}
