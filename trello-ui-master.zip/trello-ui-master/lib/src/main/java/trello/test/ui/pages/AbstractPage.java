package trello.test.ui.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import trello.test.ui.core.DriverManager;
import trello.test.ui.core.WebDriverAction;

public abstract class AbstractPage {
    protected WebDriver driver;
    protected WebDriverWait wait;
    protected WebDriverAction action;

    public AbstractPage (){
        this.driver = DriverManager.getInstance().getDriver();
        this.wait = new WebDriverWait(this.driver, 15);
        this.action = new WebDriverAction(driver, this.wait);

        PageFactory.initElements(this.driver, this);
    }

}
