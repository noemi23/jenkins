package trello.test.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Header extends AbstractPage {
    @FindBy(css = ".js-open-header-member-menu")
    private WebElement profileMenuButton;

    @FindBy(css = "[data-test-id='header-create-menu-button']")
    private WebElement createMenuButton;

    @FindBy(css = "[data-test-id='header-member-menu-logout']")
    private WebElement logoutButton;

    public Header(){
        super();
    }

    public Profile openProfileMenu(){
        this.action.click(this.profileMenuButton);
        return new Profile();
    }

    public CreateMenu openCreateMenu(){
        this.action.click(createMenuButton);
        return new CreateMenu();
    }

    public void logout(){
        this.action.click(this.profileMenuButton);
        this.action.click(logoutButton);
    }
}
