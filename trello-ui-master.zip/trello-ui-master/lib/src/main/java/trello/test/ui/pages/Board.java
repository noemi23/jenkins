package trello.test.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Board extends AbstractPage {
    private String LIST_XPATH = "//textarea[text()='%s']";

    private String CARD_XPATH = "//span[text()='%s']";

    @FindBy(css = ".mod-board-name")
    private WebElement boardTitleLabel;

    public Board() {
        super();
    }

    public String getBoardTitle(){
        return this.action.getText(boardTitleLabel);
    }

    public ListCreationForm openListForm(){
        return new ListCreationForm();
    }

    public void moveCard(String cardSource, String listTarget) {
        action.dragAndDrop(By.xpath(String.format(CARD_XPATH, cardSource)), By.xpath(String.format(LIST_XPATH, listTarget)));
    }
}
