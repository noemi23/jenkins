package trello.test.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateMenu extends AbstractPage {
    @FindBy(css = "[data-test-id='header-create-board-button']")
    private WebElement createMenuButton;

    @FindBy(css = "[data-test-id='header-create-team-button']")
    private WebElement createTeamOption;

    public CreateMenu() {
        super();
    }

    public BoardCreationForm openCreateBoardForm(){
        this.action.click(createMenuButton);
        return new BoardCreationForm();
    }

    public TeamForm openCreateTeamForm(){
        action.click(createTeamOption);
        return new TeamForm();
    }
}
