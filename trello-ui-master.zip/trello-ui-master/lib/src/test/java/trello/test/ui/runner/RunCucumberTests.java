package trello.test.ui.runner;

import io.cucumber.java.After;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import trello.test.ui.core.DriverManager;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {
                "pretty",
                "html:reports/html/index.html",
                "json:reports/cucumber-reports/cucumber.json",
//                "de.monochromata.cucumber.report.PrettyReports:reports/cucumber",
                "rerun:reports/rerun/rerun.txt"
},
        features = "src/test/resources/feature-ui",
        glue = "trello.test.ui",
        tags = "@negative"
)
public class RunCucumberTests {
//        @After
//        public static void close(){
//                DriverManager.getInstance().quit();
//        }
}
