package trello.test.ui.runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import trello.test.ui.core.DriverManager;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {
                "pretty",
//                "html:reports/html/index.html",
//                "de.monochromata.cucumber.report.PrettyReports:reports/cucumber",
                "json:reports/cucumber-reports/cucumber-retry.json",
        },

        features = "@reports/rerun/rerun.txt",
        glue = "trello.test.ui"
)
public class ReRunCucumberTests {

}
