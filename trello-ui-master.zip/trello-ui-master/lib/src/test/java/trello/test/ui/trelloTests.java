package trello.test.ui;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import trello.test.ui.core.WebDriverAction;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class trelloTests {

    private WebDriver driver;
    //WebDriverWait object to handle the timeout and expected conditions of explicit wait
    private WebDriverWait wait;
    private WebDriverAction action;
    @Before
    public void setUp(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions chromeOptions =  new ChromeOptions();
//        chromeOptions.addArguments("--headless");
        driver = new ChromeDriver(chromeOptions);
//        driver.manage().window().setSize(new Dimension(1920, 1080));
        //Configure implicit wait
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //Configure explicit wait
        wait = new WebDriverWait(driver, 20, 800);
        action = new WebDriverAction(driver, wait);
    }

    @After
    public void tearDown(){
        driver.quit();
    }

    @Test
    public void testLogin(){
            //Load home page
            driver.get("https://trello.com/");
            //Click login button
//        WebElement loginButton = driver.findElement(By.cssSelector("[href*='login']"));
//            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[href*='login44']")));
//            loginButton.click();
            action.click(By.cssSelector("[href*='login']"));

//        sleep(3);

            //Set user name
//        WebElement userTextField = driver.findElement(By.cssSelector("#user"));
//            WebElement userTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#user")));
//            userTextField.sendKeys("joseccb1948@outlook.com");
            action.sendText(By.cssSelector("#user"), "joseccb1948@outlook.com");

//            wait.until(ExpectedConditions.invisibilityOfElementLocated((By.cssSelector("#password"))));
            action.waitForInvisibility(By.cssSelector("#password"));
            //Click first Atlassian login button
//        WebElement loginAtlasianButton = driver.findElement(By.cssSelector("#login"));
//            WebElement loginAtlasianButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#login")));
//            loginAtlasianButton.click();
            action.click(By.cssSelector("#login"));

//        sleep(2);

            //Set password
//        WebElement passwordTextField = driver.findElement(By.cssSelector("#password"));
//            WebElement passwordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated((By.cssSelector("#password"))));
//            passwordTextField.sendKeys("Control*1234");
            action.sendText(By.cssSelector("#password"), "Control*1234");

//        sleep(3);

            //Click second login button
//        WebElement loginSubmitButton = driver.findElement(By.cssSelector("#login-submit"));
//            WebElement loginSubmitButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#login-submit")));
//            loginSubmitButton.click();
            action.click(By.cssSelector("#login-submit"));

//        sleep(3);

            //Click profile icon
//        WebElement profileMenuButton = driver.findElement(By.cssSelector(".js-open-header-member-menu"));
//            WebElement profileMenuButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".js-open-header-member-menu")));
//            profileMenuButton.click();
            action.click(By.cssSelector(".js-open-header-member-menu"));

//        sleep(3);

            //Validate email account
//        WebElement accountNameLabel = driver.findElement(By.xpath("//section[@data-test-id='header-member-menu-popover']/descendant::ul/div/div/span"));
//            WebElement accountNameLabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[@data-test-id='header-member-menu-popover']/descendant::ul/div/div/span")));
//            String actualAccountName = accountNameLabel.getText();
            String actualAccountName = action.getText(By.xpath("//section[@data-test-id='header-member-menu-popover']/descendant::ul/div/div/span"));
            String expectedAccountName = "joseccb1948@outlook.com";

            Assert.assertEquals(expectedAccountName, actualAccountName);
    }

    @Test
    public void testCreateBoard(){
        login();
        //Go to Boards menu
//        WebElement boardsButton = driver.findElement(By.cssSelector("[href*='boards']"));
//        boardsButton.click();
        action.click(By.cssSelector("[href*='boards']"));

        //Open boards creation menu
//        WebElement createNewBoardButton = driver.findElement(By.xpath("//div[@class='content-all-boards']/div[2]/descendant::li[@data-test-id='create-board-tile']"));
//        createNewBoardButton.click();
        action.click(By.xpath("//div[@class='content-all-boards']/div[2]/descendant::li[@data-test-id='create-board-tile']"));

//        sleep(4);

        //Set board title
//        WebElement boardTitleTextField = driver.findElement(By.cssSelector("[data-test-id='create-board-title-input']"));
//        boardTitleTextField.sendKeys("My board");
        action.sendText(By.cssSelector("[data-test-id='create-board-title-input']"), "My board");

        //Click create board
//        WebElement createBoardButton = driver.findElement(By.cssSelector("[data-test-id='create-board-submit-button']"));
//        createBoardButton.click();
        action.click(By.cssSelector("[data-test-id='create-board-submit-button']"));

//        sleep(4);

        //Validate board title
//        WebElement boardTitleLabel = driver.findElement(By.cssSelector(".mod-board-name"));
//        String actualBoardTitle = boardTitleLabel.getText();
        String actualBoardTitle = action.getText(By.cssSelector(".mod-board-name"));
        String expectedBoardTitle = "My board";

        Assert.assertEquals(expectedBoardTitle, actualBoardTitle);

    }

    //Practice 3
    @Test
    public void testCreateBoardFromCreateMenu(){
        login();
        //Go to Create menu
//        WebElement createMenuButton = driver.findElement(By.cssSelector("[data-test-id='header-create-menu-button']"));
//        createMenuButton.click();
        action.click(By.cssSelector("[data-test-id='header-create-menu-button']"));

        //Open boards creation menu
//        WebElement createNewBoardButton = driver.findElement(By.cssSelector("[data-test-id='header-create-board-button']"));
//        createNewBoardButton.click();
        action.click(By.cssSelector("[data-test-id='header-create-board-button']"));

//        sleep(4);

        //Set board title
//        WebElement boardTitleTextField = driver.findElement(By.cssSelector("[data-test-id='create-board-title-input']"));
//        boardTitleTextField.sendKeys("My board");
        action.sendText(By.cssSelector("[data-test-id='create-board-title-input']"), "My board");

        //Set public
//        WebElement privacyOptions = driver.findElement(By.xpath("//ul/preceding-sibling::div/button[2]"));
//        privacyOptions.click();
        action.click(By.xpath("//ul/preceding-sibling::div/button[2]"));
//        WebElement publicOption = driver.findElement(By.xpath("//section/descendant::li[3]"));
//        publicOption.click();
        action.click(By.xpath("//section/descendant::li[3]"));

        // Click Yes to confirm

//        WebElement confirmButton = driver.findElement(By.xpath("//section/descendant::div/button"));
//        confirmButton.click();
        action.click(By.xpath("//section/descendant::div/button"));

        //Click create board
//        WebElement createBoardButton = driver.findElement(By.cssSelector("[data-test-id='create-board-submit-button']"));
//        createBoardButton.click();
        action.click(By.cssSelector("[data-test-id='create-board-submit-button']"));
//        sleep(4);

        //Validate board title
//        WebElement boardTitleLabel = driver.findElement(By.cssSelector(".mod-board-name"));
//        String actualBoardTitle = boardTitleLabel.getText();
        String actualBoardTitle = action.getText(By.cssSelector(".mod-board-name"));
        String expectedBoardTitle = "My board";

        Assert.assertEquals(expectedBoardTitle, actualBoardTitle);

    }

    @Test
    public void testCreateList(){
        createBoard();
        //Set list title
//        WebElement listTitleFieldText = driver.findElement(By.cssSelector(".list-name-input"));
//        listTitleFieldText.sendKeys("My list");
        action.sendText(By.cssSelector(".list-name-input"), "My list");

        //Add list
//        WebElement addListButton = driver.findElement(By.cssSelector(".mod-list-add-button"));
//        addListButton.click();
        action.click(By.cssSelector(".mod-list-add-button"));

        //Validate list title
//        WebElement listTitleLabel = driver.findElement(By.cssSelector(".list-header"));
//        String actualListName = listTitleLabel.getText();
        String actualListName = action.getText(By.cssSelector(".list-header"));
        String expectedListName = "My list";

        Assert.assertEquals(expectedListName, actualListName);
    }

    @Test
    public void testCreateCard(){
        createlist();
        //Open creation card menu
//        WebElement addCardOption = driver.findElement(By.cssSelector(".open-card-composer"));
//        addCardOption.click();
        action.click(By.cssSelector(".open-card-composer"));

        //Set card title
//        WebElement cardTitleTextArea = driver.findElement(By.cssSelector(".js-card-title"));
//        cardTitleTextArea.sendKeys("My card");
        action.sendText(By.cssSelector(".js-card-title"), "My card");

        //Press Add card button
//        WebElement addCardButton = driver.findElement(By.cssSelector(".js-add-card"));
//        addCardButton.click();
        action.click(By.cssSelector(".js-add-card"));

        //Validate card title
//        WebElement cardTitleLabel = driver.findElement(By.cssSelector(".js-card-details"));
//        String actualCardTitle = cardTitleLabel.getText();
        String actualCardTitle = action.getText(By.cssSelector(".js-card-details"));
        String expectedCardTitle = "My card";

        Assert.assertEquals(expectedCardTitle, actualCardTitle);

    }

    @Test
    public void testAddDueDate(){
        createCard();
        //Open Card
//        WebElement cardElement = driver.findElement(By.cssSelector(".list-card-title"));
//        cardElement.click();
        action.click(By.cssSelector(".list-card-title"));
//        sleep(2);
        //Open Due Date
//        WebElement dueDateButton = driver.findElement(By.cssSelector(".js-add-due-date"));
//        dueDateButton.click();
        action.click(By.cssSelector(".js-add-due-date"));
//        sleep(3);
        //Click Next month
//        WebElement nextButton = driver.findElement(By.cssSelector(".pika-next"));
//        nextButton.click();
        action.click(By.cssSelector(".pika-next"));
        //Select date 1
//        WebElement dateToPick = driver.findElement(By.xpath("//button[text()='1']"));
//        dateToPick.click();
        action.click(By.xpath("//button[text()='1']"));
        //Select reminder of 10 min
//        WebElement reminderSelector = driver.findElement(By.cssSelector(".js-custom-reminder"));
//        Select selector = new Select(reminderSelector);
//        selector.selectByValue("10");
//
//        List<WebElement> selected = selector.getAllSelectedOptions();
//        for (WebElement element: selected) {
//            String content = element.getText();
//            System.out.println("selected element: " + content);
//        }
//        selector.selectByVisibleText("15 Minutes Before");
//        selector.selectByIndex(6);
        action.selectOption(By.cssSelector(".js-custom-reminder"), "15 Minutes Before");
//        WebElement saveButton = driver.findElement(By.cssSelector(".wide.confirm"));
//        saveButton.click();
        action.click(By.cssSelector(".wide.confirm"));

//        WebElement dueDateLabel = driver.findElement(By.cssSelector(".card-detail-due-date-text"));
//        String dueDate = dueDateLabel.getText();
        String dueDate = action.getText(By.cssSelector(".card-detail-due-date-text"));
        Assert.assertTrue(dueDate.contains("Feb 1"));

    }

    public void sleep(int timeInSeconds){
        try{
            Thread.sleep(timeInSeconds*1000);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    private void login(){
        driver.get("https://trello.com/");
//        WebElement loginButton = driver.findElement(By.cssSelector("[href*='login']"));
//        loginButton.click();
        action.click(By.cssSelector("[href*='login']"));

//        sleep(3);

//        WebElement userTextField = driver.findElement(By.cssSelector("#user"));
//        userTextField.sendKeys("joseccb1948@outlook.com");
        action.sendText(By.cssSelector("#user"), "joseccb1948@outlook.com");

//        WebElement loginAtlasianButton = driver.findElement(By.cssSelector("#login"));
//        loginAtlasianButton.click();
        action.waitForInvisibility(By.cssSelector("#password"));

        action.click(By.cssSelector("#login"));

//        sleep(3);

//        WebElement passwordTextField = driver.findElement(By.cssSelector("#password"));
//        passwordTextField.sendKeys("Control*1234");
        action.sendText(By.cssSelector("#password"), "Control*1234");

//        sleep(3);

//        WebElement loginSubmitButton = driver.findElement(By.cssSelector("#login-submit"));
//        loginSubmitButton.click();
        action.click(By.cssSelector("#login-submit"));

//        sleep(5);

    }

    private void createBoard(){
        login();
//        WebElement boardsButton = driver.findElement(By.cssSelector("[href*='boards']"));
//        boardsButton.click();
        action.click(By.cssSelector("[href*='boards']"));

//        WebElement createNewBoardButton = driver.findElement(By.xpath("//div[@class='content-all-boards']/div[2]/descendant::li[@data-test-id='create-board-tile']"));
//        createNewBoardButton.click();
        action.click(By.xpath("//div[@class='content-all-boards']/div[2]/descendant::li[@data-test-id='create-board-tile']"));

//        sleep(4);

//        WebElement boardTitleTextField = driver.findElement(By.cssSelector("[data-test-id='create-board-title-input']"));
//        boardTitleTextField.sendKeys("My board");
        action.sendText(By.cssSelector("[data-test-id='create-board-title-input']"), "My board");

//        WebElement createBoardButton = driver.findElement(By.cssSelector("[data-test-id='create-board-submit-button']"));
//        createBoardButton.click();
        action.click(By.cssSelector("[data-test-id='create-board-submit-button']"));

//        sleep(4);
    }

    private void createlist(){
        createBoard();
//        WebElement listTitleFieldText = driver.findElement(By.cssSelector(".list-name-input"));
//        listTitleFieldText.sendKeys("My list");
        action.sendText(By.cssSelector(".list-name-input"), "My list");

//        sleep(3);
//        WebElement addListButton = driver.findElement(By.cssSelector(".mod-list-add-button"));
//        addListButton.click();
        action.click(By.cssSelector(".mod-list-add-button"));

//        sleep(2);
    }

    private void createCard(){
        createlist();

//        WebElement addCardOption = driver.findElement(By.cssSelector(".open-card-composer"));
//        addCardOption.click();
        action.click(By.cssSelector(".open-card-composer"));

//        WebElement cardTitleTextArea = driver.findElement(By.cssSelector(".js-card-title"));
//        cardTitleTextArea.sendKeys("My card");
        action.sendText(By.cssSelector(".js-card-title"), "My card");

//        WebElement addCardButton = driver.findElement(By.cssSelector(".js-add-card"));
//        addCardButton.click();
        action.click(By.cssSelector(".js-add-card"));

//        sleep(2);
    }
}
