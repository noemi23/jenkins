package trello.test.ui;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.util.List;

public class seleniumTest {

    @Test
    public void basicCommands(){
        // Configure chrome driver
//        System.setProperty("webdriver.chrome.driver", "e:\\qa-webui\\chromedriver_win32\\chromedriver.exe");

        //setup the chromedriver using WebDriverManager
        WebDriverManager.firefoxdriver().setup();
//        WebDriverManager.chromedriver().driverVersion("2.40").setup();

        // Create webDriver, open browser
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.addArguments("--headless");
//        firefoxOptions.setHeadless(true);

        WebDriver driver = new FirefoxDriver();
        driver.manage().window().setSize(new Dimension(1920, 1080));
        // Maximize browser
//        driver.manage().window().maximize();
        // Navigate to selenium site
        driver.get("https://selenium.dev");
//        driver.navigate().to("https://selenium.dev");

        // Find download button
        WebElement downloadButton = driver.findElement(By.cssSelector(".download-button.ide"));
        downloadButton.click();
        // Find all the download buttons
//        List<WebElement> downloadButtons = driver.findElements(By.cssSelector(".download-button"));
//        String firstLocator = downloadButtons.get(0).getAttribute("class");
//        String secondLocator = downloadButtons.get(1).getAttribute("class");
//        String thirdLocator = downloadButtons.get(2).getAttribute("class");
//        downloadButtons.get(1).click();
//        WebElement searchBox = driver.findElement(By.xpath("//input[@name='search']"));
//        searchBox.sendKeys("selenium ide");
//        searchBox.clear();
//        searchBox.sendKeys("selenium webdriver");
//        searchBox.sendKeys(Keys.ENTER);
// Get text from webelement
//        WebElement homeMessage = driver.findElement(By.xpath("//h1[@class='sub-header']"));
//        String messageText = homeMessage.getText();
        // Close current tab or window
//        driver.close();
        // Close browser and kill drivers instances

        // Browser commands
        System.out.println(driver.getTitle());
        System.out.println(driver.getCurrentUrl());
        driver.navigate().back();
        driver.navigate().forward();
        driver.navigate().refresh();

        driver.quit();
    }

    @Test
    public void practice2(){

    }
}
