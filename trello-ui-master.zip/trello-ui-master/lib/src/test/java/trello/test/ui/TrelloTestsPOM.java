package trello.test.ui;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import trello.test.ui.core.DriverManager;
import trello.test.ui.pages.*;


public class TrelloTestsPOM {
    @Before
    public void setUp(){

    }

    @After
    public void tearDown(){
        DriverManager.getInstance().getDriver().quit();
    }

    @Test
    public void testLogin(){
        Welcome welcome = new Welcome();

        Login login = welcome.openLogin();
        Header header = login.login("joseccb1948@outlook.com", "Control*1234");
        Profile profile = header.openProfileMenu();
        String actualAccountEmail = profile.getAccountEmail();
        String expectedAccountEmail = "joseccb1948@outlook.com";

        Assert.assertEquals(expectedAccountEmail, actualAccountEmail);

    }

    @Test
    public void testCreateBoardFromCreateMenu(){
        Welcome welcome = new Welcome();
        Login login = welcome.openLogin();
        Header header = login.login("joseccb1948@outlook.com", "Control*1234");

        CreateMenu createMenu = header.openCreateMenu();
        BoardCreationForm boardCreationForm = createMenu.openCreateBoardForm();
        Board board = boardCreationForm.createBoard("My board");
        String actualBoardTitle = board.getBoardTitle();
        String expectedBoardTitle = "My board";

        Assert.assertEquals(expectedBoardTitle, actualBoardTitle);
    }

    @Test
    public void testCreateList(){
        Welcome welcome = new Welcome();
        Login login = welcome.openLogin();
        Header header = login.login("joseccb1948@outlook.com", "Control*1234");
        CreateMenu createMenu = header.openCreateMenu();
        BoardCreationForm boardCreationForm = createMenu.openCreateBoardForm();
        Board board = boardCreationForm.createBoard("My board");

        ListCreationForm listCreationForm = new ListCreationForm();
        ListColumn listColumn = listCreationForm.createList("My list");
        String actualTitle = listColumn.getListTitle();
        String expectedTitle = "My list";

        Assert.assertEquals(expectedTitle, actualTitle);
    }

    @Test
    public void testCreateBoardFromBoardsMenu(){
        Welcome welcome = new Welcome();
        Login login = welcome.openLogin();
        login.login("joseccb1948@outlook.com", "Control*1234");

        LeftMenuBar leftMenuBar = new LeftMenuBar();
        BoardsPage boardsPage = leftMenuBar.openBoardsPage();
        BoardCreationForm boardCreationForm = boardsPage.openCreateBoardForm();
        Board board = boardCreationForm.createBoard("My board");
        String actualBoardTitle = board.getBoardTitle();
        String expectedBoardTitle = "My board";

        Assert.assertEquals(expectedBoardTitle, actualBoardTitle);

    }
}
