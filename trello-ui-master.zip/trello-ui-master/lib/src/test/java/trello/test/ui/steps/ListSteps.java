package trello.test.ui.steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import trello.test.ui.pages.ListColumn;
import trello.test.ui.pages.ListCreationForm;

public class ListSteps {
    private ListCreationForm listCreationForm = new ListCreationForm();
    private ListColumn listColumn;


    @Then("I should see the title {string} in list")
    public void iShouldSeeTheTitleInList(String expectedListTitle) {
        String actualListTitle = listColumn.getListTitle();
        Assert.assertEquals(expectedListTitle, actualListTitle);
    }


    @When("I create the list with name {string}")
    public void iCreateTheListWithName(String listTitle) {
        listColumn = listCreationForm.createList(listTitle);
    }

}
